import React from 'react';
import '../../style/metro/oblong.styl';

class Oblong extends React.Component {
  constructor(props){
    super(props)
  }
  render(){
    return (
      <div className='oblong'>
      <div className='summary'>
        This is my first websit !
        <br />
        Welcome here !
      </div>
      <div className='detail'>
        
      </div>
    </div>
    )
  }
}

export default Oblong;