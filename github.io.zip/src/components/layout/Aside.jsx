import React from 'react';
// import Backtop from '../button/BackTop';
import '../../style/layout/aside.styl';

const Aside=()=>(
  <aside>
  </aside>
)
export default Aside ; 