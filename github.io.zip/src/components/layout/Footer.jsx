import React from 'react';

const Footer=()=>(
  <footer>底部信息</footer>
)

export default Footer;