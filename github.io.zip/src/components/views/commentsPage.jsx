import React from 'react';

class Comments extends React.Component{
  render(){
    return(
      <div>
      comments
      </div>
    )
  }
}

export default Comments;