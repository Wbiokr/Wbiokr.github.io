import React from 'react';

class Time extends React.Component{
  render(){
    return(
      <div>
        time
      </div>
    )
  }
}

export default Time;