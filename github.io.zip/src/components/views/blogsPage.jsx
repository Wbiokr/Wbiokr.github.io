import React from 'react';

class Blogs extends React.Component{
  render(){
    return(
      <div>
      Blogs
      </div>
    )
  }
}

export default Blogs;