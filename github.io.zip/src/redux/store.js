import {createStore} from 'redux';
import reducer from './reducer/';
// import state from './state/state';

 const store=createStore(reducer);

// let 

 export default store;