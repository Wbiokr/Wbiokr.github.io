const initState={
  counter:{
    num:'10',
    text:'总部state',
  }
}