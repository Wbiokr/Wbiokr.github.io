export const counter = {
  type:'ADD',
  text:'增加了！'
}

export const del={
  type:'DEL',
  text:'减少了！'
}