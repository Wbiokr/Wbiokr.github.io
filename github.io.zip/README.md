
1. npm start :开发环境
2. npm run test:生产代码更新之前本地测试环境
2. npm run build:生产环境


----------
cnpm install ;
npm start ;